// TODO 1: Buat data students
// code here
const Students = [
    "andri",
    "Hadiyan",
    "Selly"
]; 

// TODO 2: export data students
// code here
module.exports = Students;